'use strict';

var a = 'a';
var b = 'b';
var c = 'c';


console.log(a);
console.log(b);
console.log(c);